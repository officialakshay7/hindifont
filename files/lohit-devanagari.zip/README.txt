Downloaded from HindiFont.co.in
Built from upstream source: https://github.com/pravins/lohit (devanagari, v2.95.4)
License: SIL Open Font License 1.1 (see OFL.txt).
