Downloaded from HindiFont.co.in
Source: https://github.com/google/fonts/tree/main/ofl/laila
License: SIL Open Font License 1.1 (see OFL.txt) - free for personal and commercial use.
